# LATO-YOLO implementation notes

## 1. Mapping from the manuscript to code

### Section 3.2 — AFPN

Implementation: `ultralytics/nn/modules/lato.py`

- Inputs are the YOLOv12 backbone outputs `C2, C3, C4, C5` with strides 4, 8, 16 and 32.
- Stage 1 fuses `C2 + C3`.
- Stage 2 adds `C4` and fuses three levels.
- Stage 3 adds `C5` and fuses all four levels.
- Bilinear interpolation is used for upsampling.
- Stride-2 convolutions are used for downsampling.
- 1×1 projections standardize channel dimensions.
- `AdaptiveSpatialFusion` learns pixel-wise softmax weights among scales.
- The output is `[P2, P3, P4, P5]`, and the detector uses four prediction levels.

The default nano configuration uses a common 64-channel fusion width after YOLO width scaling. This keeps the AFPN lightweight while preserving four spatial scales.

### Section 3.3 — UTGhostConv

Implementation: `ultralytics/nn/modules/lato.py`

- Primary/distillation channel ratio defaults to `0.75 : 0.25` (approximately 3:1).
- The primary branch uses a standard spatial convolution.
- The distillation branch uses depthwise 3×3 convolution plus pointwise projection.
- Branch outputs are concatenated and channel-shuffled.
- The full configuration replaces three high-cost backbone downsampling convolutions with UTGhostConv.

The exact layer indices to replace are not enumerated in the manuscript. They are therefore centralized in `configs/lato-yolo.yaml` so that ablation or alternative replacement patterns can be changed without editing Python source.

### Section 3.4 — HPL

Implementation: `ultralytics/utils/lato_loss.py`

`HPL = λbox·WIoU + λcls·VFL + λdfl·DFL`

- WIoU: uses center-distance attention and WIoU-v3-style non-monotonic dynamic focusing.
- VFL: uses task-aligned IoU quality scores as soft positive labels and suppresses easy negatives.
- DFL: retains YOLO's distributional boundary regression.
- HPL is only active during training. It adds no inference-time module or parameter.

The loss coefficients `λbox`, `λcls`, `λdfl` use the standard Ultralytics `box`, `cls`, `dfl` gains. WIoU/VFL internal hyperparameters are in the model YAML.

## 2. Default full architecture

`configs/lato-yolo.yaml`

- Backbone: YOLOv12n-compatible backbone.
- Neck: AFPN replacing the original PAN-style head.
- Lightweight convolution: UTGhostConv in selected backbone downsampling stages.
- Detection: four levels, P2/P3/P4/P5.
- Loss: HPL during training.

## 3. Ablation configurations

The `configs/` directory contains the full 8-group ablation matrix:

1. YOLOv12n baseline
2. + AFPN
3. + UTGhostConv
4. + HPL
5. + AFPN + UTGhostConv
6. + UTGhostConv + HPL
7. + AFPN + HPL
8. Full LATO-YOLO

## 4. Reproducibility boundary

The manuscript describes the three improvements at method level but does not publish every engineering choice required to reproduce a repository byte-for-byte, including the exact YOLOv12 code snapshot, exact UTGhostConv replacement indices, all AFPN channel widths, and all WIoU-v3 constants. This package provides a complete, runnable implementation consistent with the described architecture and exposes those unspecified choices in YAML/code constants rather than hiding them.
