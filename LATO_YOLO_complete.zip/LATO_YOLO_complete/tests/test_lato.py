"""Minimal unit tests for LATO-YOLO custom components."""

from pathlib import Path

import torch

from ultralytics import YOLO
from ultralytics.nn.modules import AFPN, UTGhostConv

ROOT = Path(__file__).resolve().parents[1]


def test_utghostconv_shape():
    module = UTGhostConv(32, 64, k=3, s=2, ratio=0.75)
    y = module(torch.randn(1, 32, 64, 64))
    assert y.shape == (1, 64, 32, 32)


def test_afpn_shapes():
    module = AFPN([32, 64, 128, 256], [32, 32, 32, 32])
    xs = [
        torch.randn(1, 32, 64, 64),
        torch.randn(1, 64, 32, 32),
        torch.randn(1, 128, 16, 16),
        torch.randn(1, 256, 8, 8),
    ]
    ys = module(xs)
    assert [y.shape for y in ys] == [
        (1, 32, 64, 64),
        (1, 32, 32, 32),
        (1, 32, 16, 16),
        (1, 32, 8, 8),
    ]


def test_full_model_builds():
    model = YOLO(str(ROOT / "configs" / "lato-yolo.yaml")).model
    assert model.stride.tolist() == [4.0, 8.0, 16.0, 32.0]
