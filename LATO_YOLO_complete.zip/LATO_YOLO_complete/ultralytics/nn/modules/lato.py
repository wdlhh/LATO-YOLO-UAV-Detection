# Ultralytics 🚀 AGPL-3.0 License - https://ultralytics.com/license
"""LATO-YOLO custom neural network modules.

This file implements the architectural components described in Sections 3.2 and 3.3
of the supplied LATO-YOLO manuscript:

- AFPN: progressive/asymptotic multi-scale feature fusion over C2-C5.
- UTGhostConv: asymmetric primary/distillation channel convolution.

The code is intentionally self-contained and only depends on PyTorch and the local
Ultralytics Conv helper.
"""

from __future__ import annotations

import math
from collections.abc import Sequence

import torch
import torch.nn as nn
import torch.nn.functional as F

from .conv import Conv


__all__ = ("AFPN", "AFPNIndex", "AdaptiveSpatialFusion", "UTGhostConv")


def channel_shuffle(x: torch.Tensor, groups: int = 2) -> torch.Tensor:
    """Shuffle channels while gracefully handling channel counts not divisible by ``groups``."""
    b, c, h, w = x.shape
    if groups <= 1 or c % groups:
        return x
    x = x.view(b, groups, c // groups, h, w)
    x = x.transpose(1, 2).contiguous()
    return x.view(b, c, h, w)


class UTGhostConv(nn.Module):
    """Asymmetric channel-distillation lightweight convolution used by LATO-YOLO.

    The output channels are split asymmetrically into a primary branch and a
    distillation branch. With the manuscript default ``ratio=0.75``, the split is
    approximately 3:1. The primary branch uses a regular convolution to retain key
    semantics; the distillation branch derives supplementary high-frequency detail
    using depthwise + pointwise convolution. The two branches are concatenated and
    channel-shuffled.

    Args:
        c1: Input channels.
        c2: Output channels.
        k: Primary convolution kernel size.
        s: Stride.
        p: Padding for the primary convolution. ``None`` means automatic padding.
        g: Groups for the primary convolution.
        d: Dilation for the primary convolution.
        act: Activation setting passed to :class:`Conv`.
        ratio: Fraction of output channels assigned to the primary branch.
        shuffle_groups: Number of channel-shuffle groups.
    """

    default_ratio = 0.75

    def __init__(
        self,
        c1: int,
        c2: int,
        k: int = 3,
        s: int = 1,
        p: int | None = None,
        g: int = 1,
        d: int = 1,
        act: bool | nn.Module = True,
        ratio: float = 0.75,
        shuffle_groups: int = 2,
    ) -> None:
        super().__init__()
        if c1 <= 0 or c2 <= 0:
            raise ValueError(f"Channels must be positive, got c1={c1}, c2={c2}.")
        if not 0.0 < ratio <= 1.0:
            raise ValueError(f"ratio must be in (0, 1], got {ratio}.")

        primary = max(1, min(c2, math.floor(c2 * ratio)))
        distill = c2 - primary

        self.c1 = c1
        self.c2 = c2
        self.primary_channels = primary
        self.distill_channels = distill
        self.ratio = ratio
        self.shuffle_groups = shuffle_groups

        # Primary semantic branch: standard spatial convolution.
        self.primary = Conv(c1, primary, k=k, s=s, p=p, g=g, d=d, act=act)

        # Distillation branch: extract inexpensive supplementary spatial detail from
        # primary features. A pointwise projection is only needed when distill > 0.
        if distill > 0:
            self.distill = nn.Sequential(
                Conv(primary, primary, k=3, s=1, g=primary, act=act),
                Conv(primary, distill, k=1, s=1, act=act),
            )
        else:
            self.distill = None

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Apply asymmetric channel distillation and channel shuffle."""
        primary = self.primary(x)
        if self.distill is None:
            return primary
        distilled = self.distill(primary)
        return channel_shuffle(torch.cat((primary, distilled), dim=1), self.shuffle_groups)

    def forward_fuse(self, x: torch.Tensor) -> torch.Tensor:
        """Forward compatible with fused Conv modules after model export/fusion."""
        primary = self.primary.forward_fuse(x) if hasattr(self.primary, "forward_fuse") else self.primary(x)
        if self.distill is None:
            return primary
        distilled = primary
        for layer in self.distill:
            distilled = layer.forward_fuse(distilled) if hasattr(layer, "forward_fuse") else layer(distilled)
        return channel_shuffle(torch.cat((primary, distilled), dim=1), self.shuffle_groups)


class _ScaleAlign(nn.Module):
    """Align one source pyramid level to a target pyramid level.

    Level indices follow C2=0, C3=1, C4=2, C5=3. Moving toward a larger level
    index downsamples with stride-2 convolutions; moving toward a smaller level
    index upsamples bilinearly. A 1x1 projection standardizes channel dimensions.
    """

    def __init__(self, c1: int, c2: int, source_level: int, target_level: int) -> None:
        super().__init__()
        self.source_level = source_level
        self.target_level = target_level
        self.project = Conv(c1, c2, k=1, s=1)

        steps = max(target_level - source_level, 0)
        self.downsample = nn.Sequential(*(Conv(c2, c2, k=3, s=2) for _ in range(steps)))

    def forward(self, x: torch.Tensor, target_hw: tuple[int, int]) -> torch.Tensor:
        """Project and spatially align ``x`` to ``target_hw``."""
        x = self.project(x)
        if self.target_level > self.source_level:
            x = self.downsample(x)
        elif self.target_level < self.source_level:
            x = F.interpolate(x, size=target_hw, mode="bilinear", align_corners=False)

        # Odd input sizes can make stride-2 output differ by one pixel. Always make
        # the final spatial size exact so all branches can be fused safely.
        if x.shape[-2:] != target_hw:
            x = F.interpolate(x, size=target_hw, mode="bilinear", align_corners=False)
        return x


class AdaptiveSpatialFusion(nn.Module):
    """Adaptive spatial fusion for a selected target pyramid level.

    Each source feature is first aligned to the target resolution and channel width.
    A lightweight spatial gating network predicts per-pixel softmax weights across
    the participating scales. The weighted feature sum is then refined with a
    depthwise spatial convolution and pointwise projection.
    """

    def __init__(
        self,
        in_channels: Sequence[int],
        out_channels: int,
        source_levels: Sequence[int],
        target_level: int,
        compression: int = 8,
    ) -> None:
        super().__init__()
        if len(in_channels) != len(source_levels):
            raise ValueError("in_channels and source_levels must have the same length.")
        if not in_channels:
            raise ValueError("AdaptiveSpatialFusion requires at least one source feature.")

        self.target_level = target_level
        self.align = nn.ModuleList(
            _ScaleAlign(c1, out_channels, src, target_level) for c1, src in zip(in_channels, source_levels)
        )

        hidden = max(out_channels // compression, 8)
        self.weight_features = nn.ModuleList(Conv(out_channels, hidden, k=1, s=1) for _ in in_channels)
        self.weight_predictor = nn.Conv2d(hidden * len(in_channels), len(in_channels), kernel_size=1, bias=True)
        self.refine = nn.Sequential(
            Conv(out_channels, out_channels, k=3, s=1, g=out_channels),
            Conv(out_channels, out_channels, k=1, s=1),
        )

    def forward(self, xs: Sequence[torch.Tensor]) -> torch.Tensor:
        """Fuse source features into one target-level output."""
        if len(xs) != len(self.align):
            raise ValueError(f"Expected {len(self.align)} inputs, got {len(xs)}.")

        # The target-level source is normally present in each progressive stage.
        # Fall back to the first source if a custom configuration omits it.
        try:
            target_pos = [m.source_level for m in self.align].index(self.target_level)
        except ValueError:
            target_pos = 0
        target_hw = xs[target_pos].shape[-2:]

        aligned = [module(x, target_hw) for module, x in zip(self.align, xs)]
        logits = self.weight_predictor(torch.cat([m(x) for m, x in zip(self.weight_features, aligned)], dim=1))
        weights = logits.softmax(dim=1)

        fused = torch.zeros_like(aligned[0])
        for i, feature in enumerate(aligned):
            fused = fused + feature * weights[:, i : i + 1]
        return self.refine(fused)


class AFPN(nn.Module):
    """Asymptotic Feature Pyramid Network for progressive C2-C5 fusion.

    Progressive stages follow the manuscript:

    1. Fuse the semantically closest low levels C2 and C3.
    2. Add C4 and fuse C2-C4.
    3. Add C5 and fuse C2-C5.

    The module returns ``[P2, P3, P4, P5]``. These four outputs can be routed to a
    YOLO detection head through :class:`AFPNIndex` layers.

    Args:
        in_channels: Four input channel widths corresponding to C2-C5.
        out_channels: Four output channel widths corresponding to P2-P5.
        compression: Compression factor for spatial fusion weight branches.
    """

    def __init__(
        self,
        in_channels: Sequence[int],
        out_channels: Sequence[int] = (64, 128, 128, 256),
        compression: int = 8,
    ) -> None:
        super().__init__()
        if len(in_channels) != 4 or len(out_channels) != 4:
            raise ValueError("AFPN expects exactly four C2-C5 input and P2-P5 output channel values.")
        self.in_channels = tuple(int(c) for c in in_channels)
        self.out_channels = tuple(int(c) for c in out_channels)

        # Standardize the backbone features before progressive fusion.
        self.input_proj = nn.ModuleList(Conv(c1, c2, k=1, s=1) for c1, c2 in zip(in_channels, out_channels))

        # Stage 1: C2 + C3 -> S1_2, S1_3
        self.stage1 = nn.ModuleList(
            [
                AdaptiveSpatialFusion(out_channels[:2], out_channels[t], (0, 1), t, compression)
                for t in (0, 1)
            ]
        )

        # Stage 2: S1_2 + S1_3 + C4 -> S2_2, S2_3, S2_4
        stage2_in = (out_channels[0], out_channels[1], out_channels[2])
        self.stage2 = nn.ModuleList(
            [AdaptiveSpatialFusion(stage2_in, out_channels[t], (0, 1, 2), t, compression) for t in (0, 1, 2)]
        )

        # Stage 3: S2_2 + S2_3 + S2_4 + C5 -> P2, P3, P4, P5
        stage3_in = tuple(out_channels)
        self.stage3 = nn.ModuleList(
            [AdaptiveSpatialFusion(stage3_in, out_channels[t], (0, 1, 2, 3), t, compression) for t in range(4)]
        )

    def forward(self, xs: Sequence[torch.Tensor]) -> list[torch.Tensor]:
        """Return progressively fused P2-P5 features."""
        if len(xs) != 4:
            raise ValueError(f"AFPN expects four inputs [C2,C3,C4,C5], got {len(xs)}.")
        c2, c3, c4, c5 = [proj(x) for proj, x in zip(self.input_proj, xs)]

        s1_inputs = (c2, c3)
        s1 = [fusion(s1_inputs) for fusion in self.stage1]

        s2_inputs = (s1[0], s1[1], c4)
        s2 = [fusion(s2_inputs) for fusion in self.stage2]

        s3_inputs = (s2[0], s2[1], s2[2], c5)
        return [fusion(s3_inputs) for fusion in self.stage3]


class AFPNIndex(nn.Module):
    """Select one feature from AFPN's ``[P2, P3, P4, P5]`` list output."""

    def __init__(self, index: int = 0) -> None:
        super().__init__()
        if index not in (0, 1, 2, 3):
            raise ValueError(f"AFPNIndex must be 0, 1, 2, or 3; got {index}.")
        self.index = index

    def forward(self, x: Sequence[torch.Tensor]) -> torch.Tensor:
        """Return one AFPN pyramid feature."""
        return x[self.index]
