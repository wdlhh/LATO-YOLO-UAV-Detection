# Ultralytics 🚀 AGPL-3.0 License - https://ultralytics.com/license
"""Hybrid HPL loss for LATO-YOLO.

HPL combines:
- WIoU v3 style non-monotonic focusing for box regression,
- Varifocal Loss (VFL) for quality-aware classification,
- Distribution Focal Loss (DFL) for fine-grained boundary regression.

The implementation only changes training-time loss computation and therefore adds no
inference-time layers or parameters.
"""

from __future__ import annotations

from typing import Any

import torch
import torch.nn as nn
import torch.nn.functional as F

from ultralytics.utils.loss import DFLoss, v8DetectionLoss
from ultralytics.utils.tal import bbox2dist, make_anchors


class WIoUv3BBoxLoss(nn.Module):
    """Bounding-box loss using WIoU-v3-inspired dynamic non-monotonic focusing plus DFL.

    Args:
        reg_max: Number of distribution bins used by the detection head.
        alpha: Base of the non-monotonic focusing term.
        delta: Controls where the focusing gain peaks.
        momentum: EMA update rate for the running IoU-loss mean.
        eps: Numerical stability constant.
    """

    def __init__(
        self,
        reg_max: int = 16,
        alpha: float = 1.9,
        delta: float = 3.0,
        momentum: float = 0.01,
        eps: float = 1e-7,
    ) -> None:
        super().__init__()
        if alpha <= 0 or delta <= 0:
            raise ValueError("WIoU alpha and delta must be positive.")
        if not 0.0 < momentum <= 1.0:
            raise ValueError("WIoU momentum must be in (0, 1].")
        self.alpha = float(alpha)
        self.delta = float(delta)
        self.momentum = float(momentum)
        self.eps = float(eps)
        self.dfl_loss = DFLoss(reg_max) if reg_max > 1 else None
        self.register_buffer("iou_mean", torch.tensor(1.0), persistent=True)

    @staticmethod
    def _box_iou_aligned(box1: torch.Tensor, box2: torch.Tensor, eps: float) -> torch.Tensor:
        """Aligned IoU for two equally shaped xyxy box tensors, returned as ``(..., 1)``."""
        inter_lt = torch.maximum(box1[..., :2], box2[..., :2])
        inter_rb = torch.minimum(box1[..., 2:], box2[..., 2:])
        inter_wh = (inter_rb - inter_lt).clamp(min=0)
        inter = inter_wh[..., 0] * inter_wh[..., 1]

        area1_wh = (box1[..., 2:] - box1[..., :2]).clamp(min=0)
        area2_wh = (box2[..., 2:] - box2[..., :2]).clamp(min=0)
        area1 = area1_wh[..., 0] * area1_wh[..., 1]
        area2 = area2_wh[..., 0] * area2_wh[..., 1]
        union = area1 + area2 - inter + eps
        return (inter / union).unsqueeze(-1)

    def forward(
        self,
        pred_dist: torch.Tensor,
        pred_bboxes: torch.Tensor,
        anchor_points: torch.Tensor,
        target_bboxes: torch.Tensor,
        target_scores: torch.Tensor,
        target_scores_sum: torch.Tensor,
        fg_mask: torch.Tensor,
        imgsz: torch.Tensor,
        stride: torch.Tensor,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        """Compute WIoU regression loss and DFL using the standard YOLO assignment outputs."""
        del imgsz, stride  # kept for API compatibility with Ultralytics BboxLoss

        weight = target_scores.sum(-1)[fg_mask].unsqueeze(-1)
        pred_fg = pred_bboxes[fg_mask]
        target_fg = target_bboxes[fg_mask]

        iou = self._box_iou_aligned(pred_fg, target_fg, self.eps).clamp_(0.0, 1.0)
        iou_loss = 1.0 - iou

        # R_WIoU: distance attention normalized by the smallest enclosing box diagonal.
        pred_center = (pred_fg[..., :2] + pred_fg[..., 2:]) * 0.5
        target_center = (target_fg[..., :2] + target_fg[..., 2:]) * 0.5
        center_dist_sq = ((pred_center - target_center) ** 2).sum(-1, keepdim=True)

        enclose_lt = torch.minimum(pred_fg[..., :2], target_fg[..., :2])
        enclose_rb = torch.maximum(pred_fg[..., 2:], target_fg[..., 2:])
        enclose_diag_sq = ((enclose_rb - enclose_lt) ** 2).sum(-1, keepdim=True).clamp_min(self.eps)
        r_wiou = torch.exp((center_dist_sq / enclose_diag_sq.detach()).clamp(max=10.0))

        # Dynamic non-monotonic focusing. The running mean is deliberately detached:
        # it controls sample weighting and should not become part of the gradient graph.
        if self.training and iou_loss.numel():
            with torch.no_grad():
                current = iou_loss.detach().mean()
                self.iou_mean.mul_(1.0 - self.momentum).add_(current * self.momentum)

        beta = iou_loss.detach() / self.iou_mean.clamp_min(self.eps)
        focus = beta / (self.delta * torch.pow(torch.as_tensor(self.alpha, device=beta.device), beta - self.delta))
        wiou_loss = focus * r_wiou * iou_loss
        loss_iou = (wiou_loss * weight).sum() / target_scores_sum

        # DFL is retained exactly as the distributional boundary component.
        if self.dfl_loss is not None:
            target_ltrb = bbox2dist(anchor_points, target_bboxes, self.dfl_loss.reg_max - 1)
            loss_dfl = self.dfl_loss(
                pred_dist[fg_mask].view(-1, self.dfl_loss.reg_max), target_ltrb[fg_mask]
            ) * weight
            loss_dfl = loss_dfl.sum() / target_scores_sum
        else:
            loss_dfl = pred_dist.sum() * 0.0

        return loss_iou, loss_dfl


class HPLDetectionLoss(v8DetectionLoss):
    """YOLO detection criterion implementing the manuscript's HPL objective.

    The total loss uses the existing YOLO gain coefficients as the three balancing
    coefficients: ``box`` for WIoU, ``cls`` for VFL, and ``dfl`` for DFL.
    Custom HPL hyperparameters may be supplied under a top-level ``hpl`` dictionary
    in the model YAML.
    """

    def __init__(self, model: torch.nn.Module, tal_topk: int = 10, tal_topk2: int | None = None) -> None:
        super().__init__(model, tal_topk, tal_topk2)
        cfg = model.yaml.get("hpl", {}) if isinstance(getattr(model, "yaml", None), dict) else {}
        self.vfl_alpha = float(cfg.get("vfl_alpha", 0.75))
        self.vfl_gamma = float(cfg.get("vfl_gamma", 2.0))
        self.bbox_loss = WIoUv3BBoxLoss(
            reg_max=self.reg_max,
            alpha=float(cfg.get("wiou_alpha", 1.9)),
            delta=float(cfg.get("wiou_delta", 3.0)),
            momentum=float(cfg.get("wiou_momentum", 0.01)),
        ).to(self.device)

    def _varifocal_loss(
        self, pred_scores: torch.Tensor, target_scores: torch.Tensor, target_scores_sum: torch.Tensor
    ) -> torch.Tensor:
        """Quality-aware VFL with task-aligned IoU scores as positive soft labels."""
        target_scores = target_scores.to(pred_scores.dtype)
        label = (target_scores > 0).to(pred_scores.dtype)
        pred_prob = pred_scores.sigmoid()
        weight = (
            self.vfl_alpha * pred_prob.pow(self.vfl_gamma) * (1.0 - label)
            + target_scores * label
        )
        loss = F.binary_cross_entropy_with_logits(pred_scores, target_scores, reduction="none") * weight
        if self.class_weights is not None:
            loss = loss * self.class_weights
        return loss.sum() / target_scores_sum

    def get_assigned_targets_and_loss(self, preds: dict[str, torch.Tensor], batch: dict[str, Any]) -> tuple:
        """Assign targets and compute ``[WIoU, VFL, DFL]`` losses."""
        loss = torch.zeros(3, device=self.device)  # box, cls, dfl
        pred_distri, pred_scores = (
            preds["boxes"].permute(0, 2, 1).contiguous(),
            preds["scores"].permute(0, 2, 1).contiguous(),
        )
        anchor_points, stride_tensor = make_anchors(preds["feats"], self.stride, 0.5)

        dtype = pred_scores.dtype
        batch_size = pred_scores.shape[0]
        imgsz = torch.tensor(preds["feats"][0].shape[2:], device=self.device, dtype=dtype) * self.stride[0]

        targets = torch.cat((batch["batch_idx"].view(-1, 1), batch["cls"].view(-1, 1), batch["bboxes"]), 1)
        targets = self.preprocess(targets.to(self.device), batch_size, scale_tensor=imgsz[[1, 0, 1, 0]])
        gt_labels, gt_bboxes = targets.split((1, 4), 2)
        mask_gt = gt_bboxes.sum(2, keepdim=True).gt_(0.0)

        pred_bboxes = self.bbox_decode(anchor_points, pred_distri)
        _, target_bboxes, target_scores, fg_mask, target_gt_idx = self.assigner(
            pred_scores.detach().sigmoid(),
            (pred_bboxes.detach() * stride_tensor).type(gt_bboxes.dtype),
            anchor_points * stride_tensor,
            gt_labels,
            gt_bboxes,
            mask_gt,
        )

        target_scores_sum = target_scores.sum().clamp_min(1.0)
        loss[1] = self._varifocal_loss(pred_scores, target_scores, target_scores_sum)

        if fg_mask.sum():
            loss[0], loss[2] = self.bbox_loss(
                pred_distri,
                pred_bboxes,
                anchor_points,
                target_bboxes / stride_tensor,
                target_scores,
                target_scores_sum,
                fg_mask,
                imgsz,
                stride_tensor,
            )

        def _gain(name: str) -> float:
            return float(self.hyp.get(name, 1.0)) if isinstance(self.hyp, dict) else float(getattr(self.hyp, name))

        loss[0] *= _gain("box")
        loss[1] *= _gain("cls")
        loss[2] *= _gain("dfl")
        return (
            (fg_mask, target_gt_idx, target_bboxes, anchor_points, stride_tensor),
            loss,
            loss.detach(),
        )
