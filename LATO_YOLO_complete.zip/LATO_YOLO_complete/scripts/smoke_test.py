#!/usr/bin/env python3
"""Fast CPU smoke test for architecture parsing, inference, HPL, and backward propagation."""

from __future__ import annotations

import sys
from pathlib import Path

import torch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from ultralytics import YOLO  # noqa: E402


def main() -> None:
    torch.set_num_threads(1)
    model = YOLO(str(ROOT / "configs" / "lato-yolo.yaml")).model
    params = sum(p.numel() for p in model.parameters())

    model.eval()
    with torch.no_grad():
        output = model(torch.zeros(1, 3, 128, 128))
    pred = output[0] if isinstance(output, tuple) else output
    assert pred.ndim == 3, f"Unexpected inference output shape: {pred.shape}"
    assert model.stride.tolist() == [4.0, 8.0, 16.0, 32.0]

    # Direct model-loss calls happen before a Trainer injects the normal hyperparameter namespace,
    # so supply the standard detection gains explicitly for this standalone test.
    if isinstance(model.args, dict):
        model.args.update({"box": 7.5, "cls": 0.5, "dfl": 1.5})
    model.train()
    batch = {
        "img": torch.rand(1, 3, 64, 64),
        "batch_idx": torch.tensor([0]),
        "cls": torch.tensor([[0.0]]),
        "bboxes": torch.tensor([[0.5, 0.5, 0.2, 0.2]]),
    }
    loss, items = model(batch)
    loss.sum().backward()

    print("LATO-YOLO smoke test: PASS")
    print(f"Parameters: {params / 1e6:.3f} M")
    print(f"Strides: {model.stride.tolist()}")
    print(f"Loss items [WIoU, VFL, DFL]: {items.detach().cpu().tolist()}")


if __name__ == "__main__":
    main()
